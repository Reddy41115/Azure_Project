import dlt

from pyspark.sql.functions import col

# --------------------------------
# Read existing table as stream
# --------------------------------

@dlt.table
def dimtrack_source():
    return spark.readStream.table("my_catalog.my_schema.dimtrack")


# --------------------------------
# Create target streaming table
# --------------------------------

dlt.create_streaming_table("dimtrack_cdc")


# --------------------------------
# Apply Auto CDC
# --------------------------------

dlt.apply_changes(
    target="dimtrack_cdc",
    source="dimtrack_source",
    keys=["track_id"],
    sequence_by=col("updated_at"),
    stored_as_scd_type=2
)