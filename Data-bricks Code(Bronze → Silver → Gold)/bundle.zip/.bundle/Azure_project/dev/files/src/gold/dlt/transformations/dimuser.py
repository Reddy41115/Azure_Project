import dlt
from pyspark.sql.functions import col
expectations = {
  "rule_1" : "user_id IS NOT NULL"
}

# --------------------------------
# Read existing table as stream
# --------------------------------

@dlt.table
@dlt.expect_all_or_drop(expectations)
def dimuser_source():
    return spark.readStream.table("my_catalog.my_schema.dimuser")


# --------------------------------
# Create target streaming table
# --------------------------------

dlt.create_streaming_table("dimuser_cdc")


# --------------------------------
# Apply Auto CDC
# --------------------------------

dlt.apply_changes(
    target="dimuser_cdc",
    source="dimuser_source",
    keys=["user_id"],
    sequence_by=col("updated_at"),
    stored_as_scd_type=2
)