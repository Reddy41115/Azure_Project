import dlt

from pyspark.sql.functions import col

# --------------------------------
# Read existing table as stream
# --------------------------------

@dlt.table
def factstream_source():
    return spark.readStream.table("my_catalog.my_schema.factstream")


# --------------------------------
# Create target streaming table
# --------------------------------

dlt.create_streaming_table("factstream_cdc")


# --------------------------------
# Apply Auto CDC
# --------------------------------

dlt.apply_changes(
    target="factstream_cdc",
    source="factstream_source",
    keys=["user_id"],
    sequence_by=col("listen_duration"),
    stored_as_scd_type=2
)