import dlt

from pyspark.sql.functions import col

# --------------------------------
# Read existing table as stream
# --------------------------------

@dlt.table
def dimartist_source():
    return spark.readStream.table("my_catalog.my_schema.dimartist")


# --------------------------------
# Create target streaming table
# --------------------------------

dlt.create_streaming_table("dimartist_cdc")


# --------------------------------
# Apply Auto CDC
# --------------------------------

dlt.apply_changes(
    target="dimartist_cdc",
    source="dimartist_source",
    keys=["artist_id"],
    sequence_by=col("updated_at"),
    stored_as_scd_type=2
)