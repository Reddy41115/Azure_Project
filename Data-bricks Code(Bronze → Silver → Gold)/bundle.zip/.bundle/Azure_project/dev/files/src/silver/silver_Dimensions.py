# Databricks notebook source
# MAGIC %md
# MAGIC ##DimUser##

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import os 
import sys

project_pth = os.path.join(os.getcwd(),'..','..')
sys.path.append(project_pth)
from utils.transformation import reusable

# COMMAND ----------

# MAGIC %md
# MAGIC ##AUTOLOADER##

# COMMAND ----------

df_user = spark.readStream.format ('cloudFiles')\
             .option("cloudFiles.format", "parquet")\
             .option("cloudFiles.schemaLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimUser/checkpoint/")\
             .option("schemaEvolutionMode","addNewColumns")\
             .load("abfss://bronze@mystorageaccount41115.dfs.core.windows.net/DimUser")

# COMMAND ----------

spark.read.parquet("abfss://bronze@mystorageaccount41115.dfs.core.windows.net/DimUser")\
.filter("user_id = 1")\
.show()

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM delta.`abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimUser/data`
# MAGIC where user_id = 1

# COMMAND ----------

df_user = df_user.withColumn("user_name", upper(col("user_name")))

# COMMAND ----------

df_user_obj = reusable()

df_user = df_user_obj.dropColumns(df_user,['_rescued_data'])


# COMMAND ----------

df_user.writeStream.format("delta")\
            .outputMode("append")\
            .option("checkpointLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimUser/checkpoint")\
            .trigger(once=True)\
            .option("path","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimUser/data")\
            .toTable("my_catalog.my_schema.DimUser")


# COMMAND ----------

# MAGIC %md
# MAGIC ##DimArtist##

# COMMAND ----------

df_art = spark.readStream.format("cloudFiles")\
            .option("cloudFiles.format","parquet")\
            .option("cloudFiles.schemaLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimArt/chekpoint")\
            .option("schemaEvolutionMode","addNewColumns")\
            .load("abfss://bronze@mystorageaccount41115.dfs.core.windows.net/DimArtist")

# COMMAND ----------

df_art_obj = reusable()

df_art = df_art_obj.dropColumns(df_art,['_rescued_data'])
df_art = df_art.dropDuplicates(['artist_id'])
  

# COMMAND ----------

df_art.writeStream.format("delta")\
            .outputMode("append")\
            .option("checkpointLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimArt/chekpoint")\
            .trigger(once=True)\
            .option("path","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimArt/data")\
            .toTable("my_catalog.my_schema.DimArtist")

# COMMAND ----------

# MAGIC %md
# MAGIC ##DimTrack##

# COMMAND ----------

df_track = spark.readStream.format("cloudFiles")\
            .option("cloudFiles.format","parquet")\
            .option("cloudFiles.schemaLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimTrack/chekpoint")\
            .option("schemaEvolutionMode","addNewColumns")\
            .load("abfss://bronze@mystorageaccount41115.dfs.core.windows.net/DimTrack")

# COMMAND ----------

df_track = df_track.withColumn("durationFlag",when(col('duration_sec')<150,"low")\
                                            .when(col('duration_sec')<300,"medium")\
                                            .otherwise("high"))

df_track = df_track.withColumn("track_name",regexp_replace(col('track_name'),'-',' '))

df_track = reusable().dropColumns(df_track,['_rescued_data'])

# COMMAND ----------

df_track.writeStream.format("delta")\
            .outputMode("append")\
            .option("checkpointLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimTrack/chekpoint")\
            .trigger(once=True)\
            .option("path","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimTrack/data")\
            .toTable("my_catalog.my_schema.DimTrack")

# COMMAND ----------

# MAGIC %md
# MAGIC ##DimDate

# COMMAND ----------

df_date = spark.readStream.format("cloudFiles")\
            .option("cloudFiles.format","parquet")\
            .option("cloudFiles.schemaLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimDate/chekpoint")\
            .option("schemaEvolutionMode","addNewColumns")\
            .load("abfss://bronze@mystorageaccount41115.dfs.core.windows.net/DimDate")

# COMMAND ----------

df_date = reusable().dropColumns(df_date,['_rescued_data'])

df_date.writeStream.format("delta")\
            .outputMode("append")\
            .option("checkpointLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimDate/chekpoint")\
            .trigger(once=True)\
            .option("path","abfss://silver@mystorageaccount41115.dfs.core.windows.net/DimDate/data")\
            .toTable("my_catalog.my_schema.DimDate")

# COMMAND ----------

# MAGIC %md
# MAGIC ##FacrStream

# COMMAND ----------

df_fact = spark.readStream.format("cloudFiles")\
            .option("cloudFiles.format","parquet")\
            .option("cloudFiles.schemaLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/FactStream/chekpoint")\
            .option("schemaEvolutionMode","addNewColumns")\
            .load("abfss://bronze@mystorageaccount41115.dfs.core.windows.net/FactStream")

# COMMAND ----------

df_fact = reusable().dropColumns(df_fact,['_rescued_data'])

df_fact.writeStream.format("delta")\
            .outputMode("append")\
            .option("checkpointLocation","abfss://silver@mystorageaccount41115.dfs.core.windows.net/FactStream/chekpoint")\
            .trigger(once=True)\
            .option("path","abfss://silver@mystorageaccount41115.dfs.core.windows.net/FactStream/data")\
            .toTable("my_catalog.my_schema.FactStream")

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY my_catalog.my_schema.dimuser